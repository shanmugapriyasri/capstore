package BusinessAnalysis;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	@Given("^Admin page logged in$")
	public void admin_page_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^clicked on Generate Business Analysis tab$")
	public void clicked_on_Generate_Business_Analysis_tab() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^open form for asking time period$")
	public void open_form_for_asking_time_period() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^fromDate and toDate mentioned$")
	public void fromdate_and_toDate_mentioned() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Generate Analysis button clicked$")
	public void generate_Analysis_button_clicked() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^show table for analysis done$")
	public void show_table_for_analysis_done() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


	
}
